# OnRoadBreakDown
This Web Technology Product is about giving Assistance for People when their vechicles BreaksDown.

Execution Process:

Download and Install Eclipse.

Create  a WorkSpace for the project.

Import Project.

Download Apache Tomcat Server.

In the Servers Tab, Add the Server.

Download and run MySQL Installer. Add Environmental Variables.

Copy the MySQL code and run it.

Tables will be Created.

Download JDBC connector jar file.

Now, Add External Jar Files - servlet api, mail api, connectorJ.

Configure your MySQL credentials and email ID in the code.

Go to the Home.html Page and right click- run it on the Server.

You can now see the application working on your localhost.
